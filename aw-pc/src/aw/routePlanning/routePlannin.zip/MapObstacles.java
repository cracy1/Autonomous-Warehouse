package aw.routePlanning;

public enum MapObstacles {
	
	EMPTY, OBSTACLE, ROBOTONE, ROBOTTWO, ROBOTTHREE	
}
