package aw.routePlanning;

import java.util.LinkedList;

public class SpaceAndTime {
	private LinkedList<Map> spaceAndTime;
	private int timeStamp;

	public SpaceAndTime() {
		spaceAndTime = new LinkedList<Map>();
	}

	public LinkedList<Map> getSpaceAndTime() {
		return spaceAndTime;
	}

	/**
	 * 
	 * @param i
	 * @return
	 */
	public Map getMap(int i) {
		return spaceAndTime.get(i);

	}

	/**
	 * when was the robots last timestamp (last move)
	 * 
	 * @param robot
	 * @return
	 */
	public int getLastMove(MapObstacles robot) {
		int timeStamp = spaceAndTime.size();
		Map currentMap = spaceAndTime.get(timeStamp);

		while (timeStamp > 0 && !currentMap.checkMap(robot)) {
			timeStamp--;
			currentMap = spaceAndTime.get(timeStamp);
		}
		return timeStamp;

	}

	/**
	 * first thing is to find last map of that robot, add/edit the maps up to
	 * the end of the path
	 * 
	 * @param path
	 * @param robot
	 */
	public void addPath(LinkedList<Node> path, MapObstacles robot) {
		int lastMove = getLastMove(robot);
		int length = path.size();
		for (int i = lastMove + 1; i < path.size() + spaceAndTime.size(); i++) {
			if (lastMove >= spaceAndTime.size()) {
				spaceAndTime.add(new Map());
			}

			if (lastMove < spaceAndTime.size()) {
				if (robot.equals(MapObstacles.ROBOTONE)) {
					spaceAndTime.get(i).update(path.removeFirst(), null, null);
				} else if (robot.equals(MapObstacles.ROBOTTWO)) {
					spaceAndTime.get(i).update(null, path.removeFirst(), null);
				} else if (robot.equals(MapObstacles.ROBOTTHREE)) {
					spaceAndTime.get(i).update(null, null, path.removeFirst());
				}
			}
		}

	}

}
